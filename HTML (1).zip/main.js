document.getElementById("waitlistForm").addEventListener("submit", function(e){

e.preventDefault();

alert("You are added to the waitlist!");

});
